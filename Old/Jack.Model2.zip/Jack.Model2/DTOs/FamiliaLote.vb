﻿Public Class FamiliaLote
    Public Property Nome As String
    Public Property Status As String
End Class
