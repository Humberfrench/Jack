﻿Public Class CriancasInconsistentes
    Inherits Criancas

    Public Overridable Property NomeMae As String
    Public Overridable Property DescricaoStatus As String
    Public Overridable Property DescricaoIdade As String

End Class
