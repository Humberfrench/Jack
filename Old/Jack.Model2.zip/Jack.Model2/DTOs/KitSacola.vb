﻿Public Class KitSacola

    Public Property NomeKit As String
    Public Property Sexo As String
    Public Property Ordem As String
    Public Property KitItem As String
    Public Property MsgOpcional As String

End Class
