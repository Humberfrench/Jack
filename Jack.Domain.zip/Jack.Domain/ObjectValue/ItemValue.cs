﻿namespace Jack.Domain.ObjectValue
{
    public class ItemValue
    {
        public int Kit { get; set; }
        public int Ordem { get; set; }
        public string Item { get; set; }
        public string Observacao { get; set; }
        public bool Opcional { get; set; }

    }
}