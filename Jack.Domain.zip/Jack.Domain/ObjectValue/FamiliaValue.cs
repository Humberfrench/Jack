﻿
namespace Jack.Domain.ObjectValue
{
    public class FamiliaValue
    {
    
        public int Codigo {get;set;}
        public int Nome {get;set;} 
        public int Fake {get;set;}
        public int PresencaJustificada { get; set; }

    }
}
