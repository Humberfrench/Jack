﻿
namespace Jack.Domain.ObjectValue
{
    public class Stats
    {
        public string Item { get; set; }
        public double Valor { get; set; } 
    }
}