﻿
namespace Jack.Domain.ObjectValue
{
    public class RoupaValue
    {
        public string Roupa { get; set; }
        public string RoupaGrande { get; set; }
    }
}