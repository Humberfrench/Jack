﻿namespace Jack.Domain.Enum
{
    public enum EnumGrauParentesco
    {
        PrimeiroGrau = 1,
        SegundoGrau = 2,
        NaoParente = 3
    }
}