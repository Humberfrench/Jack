﻿namespace Jack.Domain.Enum
{
    public enum EnumNivel
    {
        Nivel1 = 1,
        Nivel2 = 2,
        Nivel3 = 3,
        Nivel4 = 4,
        Nivel5 = 5,
        Nivel6 = 6,
        Nivel7 = 7,
        Nivel98 = 98,
        Nivel99 = 99

    }
}