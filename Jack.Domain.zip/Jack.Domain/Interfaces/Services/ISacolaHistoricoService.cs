﻿using Jack.Domain.Entity;

namespace Jack.Domain.Interfaces.Services
{
    public interface ISacolaHistoricoService : IServiceBase<SacolaHistorico>
    {

    }
}