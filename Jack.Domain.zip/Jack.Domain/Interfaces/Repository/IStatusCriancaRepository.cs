﻿using Jack.Domain.Entity;

namespace Jack.Domain.Interfaces.Repository
{
    public interface IStatusCriancaRepository : IRepositoryBase<StatusCrianca>
    {
         
    }
}