﻿using Jack.Domain.Entity;

namespace Jack.Domain.Interfaces.Repository
{
    public interface ISacolaHistoricoRepository : IRepositoryBase<SacolaHistorico>
    {
    }
}