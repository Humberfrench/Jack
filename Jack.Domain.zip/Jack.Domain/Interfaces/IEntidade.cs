﻿
namespace Jack.Domain.Interfaces
{
    public interface IEntidade
    {
        //int Codigo { get; }

    }
}
