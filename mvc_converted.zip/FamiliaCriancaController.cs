
using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Web.Mvc;

namespace Controllers.MVC
{
	public class FamiliaCriancaController : Controller
	{

		// GET: FamiliaCrianca
		public ActionResult Index()
		{
			return View();
		}

		public ActionResult Representante()
		{
			return View();
		}

	}
}

//=======================================================
//Service provided by Telerik (www.telerik.com)
//Conversion powered by NRefactory.
//Twitter: @telerik
//Facebook: facebook.com/telerik
//=======================================================
